import { parseLRC, parsePlain, fmtTime } from './lrc.js';
import * as svc from './services.js';
import { PlaybackManager } from './playback.js';
import { searchAll, resolveFull, groupTracks, providers } from './providers/registry.js';
import { musickit } from './providers/musickit.js';
import { youtube } from './providers/youtube.js';
import { itunes } from './providers/itunes.js';
import { CONFIG } from './config.js';
import { STYLES } from './viz/index.js';
import { frameState, esc, clamp } from './viz/core.js';
import { rankFull } from './rank.js';

const $ = s => document.querySelector(s);
const FONTS = { 'Figtree': "'Figtree'", 'Rounded (Nunito)': "'Nunito'", 'Serif (Fraunces)': "'Fraunces',Georgia", 'Neutral (Arimo)': "'Arimo',Helvetica,Arial", 'Grotesk (Inter)': "'Inter'", 'Geometric (Jost)': "'Jost'", 'Didone (Playfair)': "'Playfair Display',Didot" };
const DEF = { mapHometown: true, openSearch: true, style: 'visual', font: 'Figtree', scale: 1, text: '#ffffff', hi: '#ffffff', sec: '#6b6a73', cover: true, ytKey: '', vol: 0.8 };
const load = () => { try { return { ...DEF, ...JSON.parse(localStorage.getItem('verci2') || '{}') }; } catch { return { ...DEF }; } };
const S = {
  set: load(), res: {}, track: null, group: null, playable: null, resolved: null, nudge: 0,
  lyrics: null, lstate: { status: 'idle' }, viz: null, vizId: null, theme: { hi: '#fff', sec: 'rgba(255,255,255,.34)', scale: 1 }, seeking: false
};
const save = () => { try { localStorage.setItem('verci2', JSON.stringify(S.set)); } catch {} };
const player = new PlaybackManager($('#ytMount'));
player.setVolume(S.set.vol);

/* ---------------- small UI helpers ---------------- */
let toastT;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, 3600); }
const dur = ms => ms ? fmtTime(ms / 1000) : '';
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16},${(n >> 8) & 255},${n & 255},${a})`; };
const mix = (c, w, k) => c.map((v, i) => Math.round(v + (w[i] - v) * k));
const hex = c => '#' + c.map(v => v.toString(16).padStart(2, '0')).join('');
function state(title, body, extra = '') { return `<div class="state"><b>${esc(title)}</b>${body}${extra}</div>`; }

/* ---------------- theme ---------------- */
async function artColor(url) {
  return new Promise(res => {
    if (!url) return res(null);
    const im = new Image(); im.crossOrigin = 'anonymous';
    im.onload = () => {
      try {
        const c = document.createElement('canvas'); c.width = c.height = 16; const g = c.getContext('2d'); g.drawImage(im, 0, 0, 16, 16);
        const d = g.getImageData(0, 0, 16, 16).data; let best = null, bs = -1;
        for (let i = 0; i < d.length; i += 4) { const r = d[i], gg = d[i + 1], b = d[i + 2], mx = Math.max(r, gg, b), mn = Math.min(r, gg, b), s = (mx - mn) * (mx / 255 + 0.2); if (s > bs) { bs = s; best = [r, gg, b]; } }
        res(best);
      } catch { res(null); }
    };
    im.onerror = () => res(null); im.src = url;
  });
}
async function applyTheme() {
  const r = document.documentElement.style, s = S.set; let hi = s.hi, sec = rgba(s.sec, 1), accent = '#8fa8ff';
  if (S.track && s.cover) {
    const c = await artColor(S.track.artwork);
    if (c) { accent = hex(c); hi = hex(mix(c, [255, 255, 255], 0.62)); sec = rgba(hex(mix(c, [255, 255, 255], 0.15)), 0.4); }
  }
  S.theme = { hi, sec, scale: s.scale };
  r.setProperty('--hi', hi); r.setProperty('--sec', sec); r.setProperty('--accent', accent);
  r.setProperty('--lyric', s.text); r.setProperty('--lyric-scale', s.scale);
  r.setProperty('--lyric-font', FONTS[s.font] + ",system-ui,sans-serif");
}

/* ---------------- routing & views ---------------- */
function show(view) {
  document.body.dataset.view = view;
  for (const v of ['home', 'results', 'stage']) $('#' + v).hidden = v !== view;
  if (view !== 'stage') document.fullscreenElement && document.exitFullscreen?.();
}
function route() {
  const h = decodeURIComponent(location.hash.slice(1)) || '/';
  if (h.startsWith('/search/')) { const q = h.slice(8); $('#q').value = q; runSearch(q); show('results'); }
  else if (h === '/stage' && S.track) show('stage');
  else { show('home'); loadTrending(); }
}
addEventListener('hashchange', route);
$('#searchForm').addEventListener('submit', e => { e.preventDefault(); const q = $('#q').value.trim(); if (q) location.hash = '/search/' + encodeURIComponent(q); $('#q').blur(); });

/* ---------------- home ---------------- */
let trendingDone = false;
async function loadTrending() {
  if (trendingDone) return; trendingDone = true;
  try {
    const list = await svc.trending(); if (!list.length) return;
    $('#trending').innerHTML = list.map((t, i) => `<button class="card" data-i="${i}"><img loading="lazy" alt="" src="${esc(t.artwork)}"><b>${esc(t.title)}</b><span>${esc(t.artist)}</span></button>`).join('');
    $('#trending').onclick = e => { const b = e.target.closest('.card'); if (b) openTrack(list[+b.dataset.i], list, +b.dataset.i); };
    $('#trendingShelf').hidden = false;
  } catch { trendingDone = false; }
}

/* ---------------- search (one unified list; providers hidden) ---------------- */
let searchSeq = 0;
async function runSearch(q) {
  const my = ++searchSeq;
  if (S.res[q]?.status === 'ok') return renderResults(q);
  S.res[q] = { status: 'loading' }; renderResults(q);
  try { S.res[q] = { status: 'ok', ...(await searchAll(q)) }; } catch (e) { S.res[q] = { status: 'err', err: e.message }; }
  if (my === searchSeq) renderResults(q);
}
const dm = ms => ms ? ' · ' + dur(ms) : '';
function linkBox() { return `<div class="inline" style="margin:8px 0 18px"><input id="ytLink" placeholder="Have a YouTube link? Paste it" aria-label="YouTube link"><button class="btn" id="ytGo" style="margin:0">Play</button></div>`; }
function renderResults(q) {
  const r = S.res[q] || { status: 'loading' }, body = $('#resultBody');
  if (r.status === 'loading') return void (body.innerHTML = '<div class="spin" role="status" aria-label="Searching"></div>');
  if (r.status === 'err') return void (body.innerHTML = state('Search is unavailable', `<p>${esc(r.err)}. Check your connection and try again.</p>`, '<button class="btn" id="retry">Try again</button>'));
  if (!r.groups.length) return void (body.innerHTML = state(`Nothing found for “${q}”`, '<p>Try the song title with the artist’s name, or check the spelling.</p>') + linkBox());
  const mainstream = r.skipped.includes('youtube') && r.skipped.includes('musickit');
  body.innerHTML = `<div class="list">` + r.groups.map((g, i) => { const t = g.identity; return `<button class="row" data-i="${i}"><img loading="lazy" alt="" src="${esc(t.artwork)}"><div><b>${esc(t.title)}${t.explicit ? ' <small class="x">E</small>' : ''}</b><span>${esc(t.artist)}${t.album ? ' · ' + esc(t.album) : ''}${dm(t.durationMs)}</span></div><i class="tag${g.playables.length ? ' ok' : ''}">${g.playables.length ? 'Full' : ''}</i></button>`; }).join('') + '</div>'
    + (mainstream ? `<p class="note" style="margin:18px 8px">Only independent music can be played until YouTube or Apple Music is set up. <button class="lnk" id="howBtn2">How?</button></p>` : '')
    + Object.entries(r.errors).map(([k, v]) => `<p class="note" style="margin:6px 8px">${esc(providers.find(p => p.id === k)?.name || k)} is unavailable right now (${esc(v)}).</p>`).join('') + linkBox();
  body.onclick = e => { const b = e.target.closest('.row'); if (b) openTrack(r.groups[+b.dataset.i], r.groups, +b.dataset.i); };
}
document.addEventListener('click', e => {
  if (e.target.id === 'retry') { const q = decodeURIComponent(location.hash.slice(9)); delete S.res[q]; runSearch(q); }
  if (e.target.id === 'ytGo') { const v = svc.youtubeId($('#ytLink').value); v ? openYouTube(v) : toast('That does not look like a YouTube link.'); }
  if (e.target.id === 'howBtn2') $('#howDlg').showModal();
});
async function openYouTube(id) {
  try { toast('Loading video…'); const t = youtube.fromLink(await svc.youtubeInfo(id)); const g = groupTracks([t])[0]; openTrack(g, [g], 0); }
  catch { toast('That video could not be found or cannot be embedded.'); }
}

/* ---------------- opening a track ---------------- */
async function resolveRss(item) {
  const n = s => svc.cleanText(s).toLowerCase().replace(/[^a-z0-9]/g, '');
  const list = await itunes.search(`${item.title} ${item.artist}`);
  const t = list.find(x => n(x.title) === n(item.title) && n(x.artist).includes(n(item.artist).slice(0, 6))) || list[0];
  return t ? groupTracks([t])[0] : null;
}
const noFullHTML = () => {
  const r = S.resolved; if (r?.needsAuth) return '<b>Sign in to Apple Music</b> to play this song in full. <button data-act="am">Sign in</button>';
  return `<b>No full version found.</b> ${r?.blocked ? 'The matching YouTube uploads do not allow embedding. ' : ''}Previews are never played. <button data-act="sources">Choose a source</button>`;
};
async function openTrack(item, list, index, auto = true) {
  player.setQueue(list, index);
  let g = item;
  if (item.source === 'rss') { toast('Finding this song…'); try { g = await resolveRss(item); } catch {} if (!g) return toast('This song could not be found.'); player.queue = list.map(x => x); player.queue[index] = g; }
  if (!g.identity) g = groupTracks([g])[0];
  const t = g.identity;
  S.track = t; S.group = g; S.nudge = 0; S.lyrics = null; S.lstate = { status: 'loading' }; S.playable = null; S.resolved = null; S.finding = true; S.playError = null;
  player.stop();
  $('body').classList.add('has-player'); $('#player').hidden = false; syncBar();
  location.hash = '/stage'; show('stage'); applyTheme(); buildStage(); renderRail(); setMedia();
  fetchLyrics(t);
  let r; try { r = await resolveFull(t, g.playables); } catch { r = { ranked: [], confident: false, errors: {} }; }
  if (S.track !== t) return;
  S.finding = false; S.resolved = r;
  if (r.confident) S.playable = r.best.track.playback;
  buildStage(); syncBar();
  if (S.playable) { S.tried = new Set([S.playable.videoId || S.playable.url || S.playable.songId]); player.load(S.playable, auto).catch(onPlayFail); }
}
async function switchTo(p, why) { S.playable = p; S.playError = null; buildStage(); syncBar(); try { await player.load(p, true); } catch (e) { onPlayFail(e); } if (why) toast(why); }
// A source that will not play (embedding disabled, host down): quietly move to the next-best candidate that still agrees.
function onPlayFail(e) {
  const r = S.resolved, tried = S.tried || (S.tried = new Set()); if (S.playable) tried.add(S.playable.videoId || S.playable.url || S.playable.songId);
  const best = r?.best?.score ?? 0, next = (r?.ranked || []).find(c => c.track?.playback && !tried.has(c.track.playback.videoId || c.track.playback.url || c.track.playback.songId) && c.score >= best - 1.2 && c.ts >= 0.7);
  if (next) { toast('That source would not play, trying another…'); return switchTo(next.track.playback); }
  S.playError = e?.message || 'This source could not be played.'; buildStage();
}
async function fetchLyrics(t, override) {
  const my = S.track;
  try {
    const r = override || await svc.lrclibFind({ title: t.title, artist: t.artist, album: t.album, raw: t.raw, source: t.source, durationSec: (t.durationMs || 0) / 1000 });
    if (my !== S.track) return;
    if (!r) S.lstate = { status: 'none' };
    else if (r.instrumental && !r.syncedLyrics && !r.plainLyrics) S.lstate = { status: 'instrumental', meta: r };
    else if (r.syncedLyrics) { const L = parseLRC(r.syncedLyrics); S.lyrics = L; S.lstate = L.lines.some(l => l.text) ? { status: 'synced', meta: r } : { status: 'none' }; }
    else { S.lyrics = parsePlain(r.plainLyrics); S.lstate = { status: 'plain', meta: r }; }
  } catch (e) { if (my === S.track) S.lstate = { status: 'error', msg: e.message }; }
  buildStage(); syncBar();
}

/* ---------------- stage (lyric view) ---------------- */
function banner(html, ttl) {
  const b = $('#banner'); clearTimeout(banner.t);
  b.innerHTML = html ? html + '<button class="x" data-act="x" aria-label="Dismiss">✕</button>' : ''; b.hidden = !html;
  if (html && ttl) banner.t = setTimeout(() => b.hidden = true, ttl);
}
function buildStage() {
  const root = $('#vizRoot'); S.viz?.destroy(); S.viz = null; S.vizId = null; root.querySelectorAll('.plain,.empty').forEach(e => e.remove());
  const st = S.lstate.status;
  $('#ytBox').hidden = S.playable?.provider !== 'youtube';
  const link = '<button data-act="sources">Fix</button>';
  if (st === 'loading') { banner(''); root.insertAdjacentHTML('beforeend', '<div class="empty"><div class="spin" style="margin:0 auto"></div></div>'); }
  else if (st === 'none') { banner(''); root.insertAdjacentHTML('beforeend', `<div class="empty"><b>No lyrics found</b><span>LRCLIB has no lyrics for “${esc(S.track.title)}” by ${esc(S.track.artist)}.</span><span><button class="btn" data-act="sources">Search lyrics manually</button></span></div>`); }
  else if (st === 'instrumental') { banner(''); root.insertAdjacentHTML('beforeend', '<div class="empty"><b>Instrumental</b><span>This track has no lyrics.</span></div>'); }
  else if (st === 'error') { banner(''); root.insertAdjacentHTML('beforeend', `<div class="empty"><b>Lyrics are unavailable</b><span>${esc(S.lstate.msg || 'The lyrics service did not answer.')}</span><span><button class="btn" id="relyrics">Try again</button></span></div>`); }
  else if (st === 'plain') { banner(`Lyrics aren’t timed, so styles can’t follow the music. ${link}`); root.insertAdjacentHTML('beforeend', `<div class="plain"><pre>${esc(S.lyrics.lines.map(l => l.text).join('\n'))}</pre></div>`); }
  else {
    banner(S.finding ? 'Finding the full song…' : S.playError ? `<b>${esc(S.playError)}</b> <button data-act="sources">Choose a source</button>` : !S.playable ? noFullHTML() : '');
    setStyle(S.set.style);
  }
  // audio problems must be visible whatever the lyric state is
  if (st !== 'synced' && st !== 'plain') { if (S.playError) banner(`<b>${esc(S.playError)}</b> <button data-act="sources">Choose a source</button>`); else if (!S.finding && !S.playable) banner(noFullHTML()); }
  $('#stagebar').hidden = st !== 'synced';
}
function setStyle(id) {
  const def = STYLES.find(s => s.id === id) || STYLES[0]; S.set.style = def.id; save();
  S.viz?.destroy(); S.viz = null;
  if (S.lstate.status === 'synced') {
    const ctx = { song: S.track, lyrics: S.lyrics, theme: S.theme, duration: () => player.duration, opts: { hometown: () => S.set.mapHometown !== false } };
    S.viz = new def.make($('#vizRoot'), ctx).mount(); S.vizId = def.id;
  }
  document.querySelectorAll('#styleGrid [data-style]').forEach(b => b.setAttribute('aria-pressed', b.dataset.style === def.id));
  $('#styleName').textContent = def.name;
}
const BLURB = { 'ship': 'Words land on a drifting 3D wall', 'fisheye': 'Three words through a bouncing lens', 'visual': 'Centred stack, one word a row', 'fisheye-visual': 'The lens, with icons', 'codestyle': 'Editor, shell and git diff', 'codestyle-visual': 'The same, with icons', 'branches': 'A cherry tree at night', 'web': 'A spider drops to each word', 'constellation': 'Stars joined into a path', 'kinetic': 'Full-bleed cuts, one word a frame', 'collage': 'Cut-and-paste mixed media', 'y2k': 'Liquid chrome, sparkles, neon grid', 'cinema': 'A typographic film edit', 'native-messages': 'A chat with a real keyboard', 'native-money': 'A feed of payments', 'native-map': 'Night navigation, a street per line', 'native-notifications': 'iPhone lock screen' };
function renderRail() {
  let g = '', h = '';
  for (const s of STYLES) { if (g !== s.group) { if (g) h += '</div></div>'; h += `<div><h3>${s.group}</h3><div class="g">`; g = s.group; } h += `<button data-style="${s.id}" aria-pressed="false"><b>${s.name}</b><span>${BLURB[s.id] || ''}</span></button>`; }
  $('#styleGrid').innerHTML = h + '</div></div>';
}
$('#styleGrid').addEventListener('click', e => { const b = e.target.closest('[data-style]'); if (b) { setStyle(b.dataset.style); $('#styleDlg').close(); } });
$('#styleBtn').onclick = () => $('#styleDlg').showModal();
const stepStyle = d => { const i = STYLES.findIndex(s => s.id === S.set.style); setStyle(STYLES[(i + d + STYLES.length) % STYLES.length].id); };
$('#stylePrev').onclick = () => stepStyle(-1); $('#styleNext').onclick = () => stepStyle(1);
$('#stage').addEventListener('click', e => {
  if (e.target.dataset.act === 'sources') openSources();
  if (e.target.dataset.act === 'am') connectApple();
  if (e.target.dataset.act === 'x') $('#banner').hidden = true;
  if (e.target.id === 'relyrics') { S.lstate = { status: 'loading' }; buildStage(); fetchLyrics(S.track); }
});

/* ---------------- frame loop ---------------- */
let last = performance.now();
function lyricTime() { return player.time + S.nudge; }
function loop(now) {
  const dt = Math.min(0.1, (now - last) / 1000); last = now;
  if (!document.hidden) {
    if (S.viz && S.lyrics && !$('#stage').hidden) S.viz.frame(frameState(S.lyrics, lyricTime()), dt);
    if (!$('#player').hidden) updateBar();
  }
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);

/* ---------------- player bar ---------------- */
const pb = $('#player');
function syncBar() {
  const t = S.track; if (!t) return;
  $('#npArt').src = t.artwork || ''; $('#npTitle').textContent = t.title; $('#npArtist').textContent = t.artist;
  const p = S.playable, L = S.lstate.status;
  document.body.dataset.src = S.playable?.videoId || S.playable?.url || S.playable?.songId || '';
  const sync = L === 'synced' ? (S.lyrics.wordLevel ? 'word-synced lyrics' : S.lyrics.wordCoverage > 0 ? 'partly word-synced, other words estimated' : 'line-synced lyrics, words estimated') : L === 'plain' ? 'lyrics not timed' : L === 'loading' ? 'finding lyrics…' : 'no lyrics';
  const b = $('#npBadge'); b.textContent = !p ? (S.finding ? '' : 'No audio') : p.label.split(' · ')[1] || 'Full'; b.className = 'badge'; b.title = (p ? p.label : 'No audio') + ' · ' + sync;
  $('#nudgeVal').textContent = (S.nudge >= 0 ? '+' : '') + S.nudge.toFixed(1) + 's';
  const multi = player.queue.length > 1; $('#prevBtn').disabled = $('#nextBtn').disabled = !multi; $('#prevBtn').style.opacity = $('#nextBtn').style.opacity = multi ? 1 : 0.3;
}
function updateBar() {
  pb.classList.toggle('playing', player.playing);
  $('#playBtn').setAttribute('aria-label', player.playing ? 'Pause' : 'Play');
  const d = player.duration, t = player.time;
  $('#tCur').textContent = fmtTime(t); $('#tDur').textContent = fmtTime(d);
  if (!S.seeking) { const v = d ? t / d * 1000 : 0, s = $('#seek'); s.value = v; s.style.setProperty('--p', v / 10 + '%'); }
}
$('#playBtn').onclick = () => S.playable ? player.toggle() : toast('There is no full-length audio for this song yet.');
$('#seek').addEventListener('input', e => { S.seeking = true; e.target.style.setProperty('--p', e.target.value / 10 + '%'); $('#tCur').textContent = fmtTime(e.target.value / 1000 * player.duration); });
$('#seek').addEventListener('change', e => { player.seek(e.target.value / 1000 * player.duration); S.seeking = false; });
$('#vol').value = S.set.vol * 100; $('#vol').style.setProperty('--p', S.set.vol * 100 + '%');
$('#vol').addEventListener('input', e => { S.set.vol = e.target.value / 100; e.target.style.setProperty('--p', e.target.value + '%'); player.setVolume(S.set.vol); save(); });
const step = d => { const g = player.step(d); if (g) openTrack(g, player.queue, player.index); };
$('#prevBtn').onclick = () => player.time > 4 ? player.seek(0) : step(-1);
$('#nextBtn').onclick = () => step(1);
$('#nudgeEarly').onclick = () => { S.nudge = Math.round((S.nudge - 0.5) * 10) / 10; syncBar(); };
$('#nudgeLate').onclick = () => { S.nudge = Math.round((S.nudge + 0.5) * 10) / 10; syncBar(); };
$('#npBtn').onclick = () => { location.hash = '/stage'; };
const more = $('#more'), moreBtn = $('#moreBtn');
moreBtn.onclick = e => { e.stopPropagation(); more.hidden = !more.hidden; moreBtn.setAttribute('aria-expanded', !more.hidden); };
document.addEventListener('click', e => { if (!more.hidden && !more.contains(e.target)) { more.hidden = true; } });
$('#more').addEventListener('click', e => { if (e.target.closest('#sourcesBtn,#fsBtn')) more.hidden = true; });
$('#fsBtn').onclick = () => document.fullscreenElement ? document.exitFullscreen() : ($('#stage').requestFullscreen?.() || toast('Full screen is not supported here.'));
$('#sourcesBtn').onclick = () => openSources();
player.addEventListener('state', () => {
  const t = S.track; if (!t || t.source !== 'youtube' || t.durationMs || !player.duration || player.mode !== 'yt') return;
  t.durationMs = player.duration * 1000; const m = S.lstate.meta;
  if (S.lstate.status !== 'synced' || (m && Math.abs(m.duration - player.duration) > 8)) { const keep = S.lstate; fetchLyrics(t).then(() => { if (S.lstate.status === 'none' && keep.status === 'synced') { S.lstate = keep; buildStage(); syncBar(); } }); }
});
player.addEventListener('ended', () => { if (player.queue.length > 1) step(1); });
player.addEventListener('error', e => onPlayFail(new Error(e.detail)));
document.addEventListener('keydown', e => {
  if (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.metaKey || e.ctrlKey) return;
  if (e.key === ' ' && S.track) { e.preventDefault(); player.toggle(); }
  else if (e.key === 'ArrowRight' && S.track) player.seek(Math.min(player.duration, player.time + 5));
  else if (e.key === 'ArrowLeft' && S.track) player.seek(Math.max(0, player.time - 5));
  else if ((e.key === ']' || e.key === '[') && S.lstate.status === 'synced') stepStyle(e.key === ']' ? 1 : -1);
  else if (e.key === 'f' && S.track) $('#fsBtn').click();
});
function setMedia() {
  if (!('mediaSession' in navigator) || !S.track) return;
  navigator.mediaSession.metadata = new MediaMetadata({ title: S.track.title, artist: S.track.artist, album: S.track.album || '', artwork: S.track.artwork ? [{ src: S.track.artwork, sizes: '512x512' }] : [] });
  for (const [a, f] of [['play', () => player.play()], ['pause', () => player.pause()], ['nexttrack', () => step(1)], ['previoustrack', () => step(-1)]]) try { navigator.mediaSession.setActionHandler(a, f); } catch {}
}

/* ---------------- source & lyrics sheet ---------------- */
const dlg = $('#sourcesDlg');
function openSources() { renderSources(); dlg.showModal(); renderFull(); }
async function renderFull() {
  const t = S.track; if (!t) return; const box = $('#fullList'); if (!box) return;
  let r = S.resolved;
  if (!r) { box.innerHTML = '<div class="spin" style="margin:12px 0"></div>'; try { r = S.resolved = await resolveFull(t, S.group?.playables || []); } catch { r = null; } }
  if (!$('#fullList') || S.track !== t) return;
  const items = (r?.ranked || []).slice(0, 8); window._full = items;
  const am = providers.find(p => p.id === 'musickit'), pn = x => providers.find(p => p.id === x.track.provider)?.name || x.track.provider;
  box.innerHTML = (am.enabled() && !am.authorized ? `<button class="row" data-act="am" style="grid-template-columns:1fr auto"><div><b>Sign in to Apple Music</b><span>Plays the exact recording in full if you have a subscription</span></div><i class="tag">Sign in</i></button>` : '')
    + (items.length ? items.map((x, i) => `<button class="row" data-full="${i}" style="grid-template-columns:1fr auto"><div><b>${esc(x.title)}</b><span>${esc(x.artist)}${dm(x.durationMs)} · ${esc(pn(x))}</span></div><i class="tag">${i === 0 && r.confident ? 'Best match' : 'Play'}</i></button>`).join('') : `<p class="note">No full-length match found. Previews are never played. Independent music comes from Audius; for mainstream songs set up YouTube or Apple Music (README → Worker), or paste a link below.</p>`);
}
function lyricsLine() {
  const s = S.lstate, m = s.meta;
  if (s.status === 'synced') return `LRCLIB · ${esc(m.artistName)} – ${esc(m.trackName)} · ${S.lyrics.wordLevel ? 'word-level timing' : S.lyrics.wordCoverage > 0 ? 'partly word-level, other words estimated' : 'line timing (words estimated)'}`;
  if (s.status === 'plain') return `LRCLIB · ${esc(m.artistName)} – ${esc(m.trackName)} · not timed`;
  return { loading: 'Searching…', none: 'No lyrics found', instrumental: 'Instrumental', error: 'Lyrics service unavailable', idle: '' }[s.status];
}
function renderSources() {
  const t = S.track, p = S.playable;
  $('#sourcesBody').innerHTML = `
  <div><h3>Now playing</h3><p>${esc(t.title)} — ${esc(t.artist)}</p><p class="note">${p ? esc(p.label) : 'No full-length audio yet'}</p></div>
  <div><h3>Play the full song instead</h3><div id="fullList" class="list"></div>
    <div class="inline" style="margin-top:10px"><input id="ytLink" placeholder="Or paste a YouTube link" aria-label="YouTube link"><button class="btn" id="ytGo2" style="margin:0">Play</button></div></div>
  <div><h3>Lyrics</h3><p class="note" id="lyrNow">${lyricsLine()}</p>
    <form id="lyrForm" class="inline" style="margin-top:10px"><input id="lyrQ" value="${esc(t.source === 'youtube' ? svc.cleanText(t.raw || t.title) : svc.cleanText(t.title) + ' ' + svc.cleanText(t.artist))}" aria-label="Search lyrics"><button class="btn" style="margin:0">Search</button></form>
    <div id="lyrRes" class="list" style="margin-top:8px"></div></div>`;
}
dlg.addEventListener('click', async e => {
  const f = e.target.closest('[data-full]'); if (f) { const x = window._full[+f.dataset.full]; dlg.close(); switchTo(x.track.playback); return; }
  const l = e.target.closest('[data-lyr]'); if (l) { const r = window._lyr[+l.dataset.lyr]; S.lstate = { status: 'loading' }; buildStage(); dlg.close(); fetchLyrics(S.track, r); return; }
  if (e.target.id === 'ytGo2') { const v = svc.youtubeId($('#ytLink').value); if (!v) return toast('That does not look like a YouTube link.'); dlg.close(); switchTo({ capability: 'full', kind: 'full', engine: 'youtube', videoId: v, label: 'Full song · YouTube' }); }
});
dlg.addEventListener('submit', async e => {
  if (e.target.id !== 'lyrForm') return; e.preventDefault();
  const box = $('#lyrRes'); box.innerHTML = '<div class="spin" style="margin:8px 0"></div>';
  try {
    const r = (await svc.lrclibSearch($('#lyrQ').value)).filter(x => x.syncedLyrics || x.plainLyrics).slice(0, 12); window._lyr = r;
    box.innerHTML = r.length ? r.map((x, i) => `<button class="row" data-lyr="${i}" style="grid-template-columns:1fr auto"><div><b>${esc(x.trackName)}</b><span>${esc(x.artistName)} · ${fmtTime(x.duration)}</span></div><i class="tag">${x.syncedLyrics ? 'Timed' : 'Not timed'}</i></button>`).join('') : '<p class="note">No lyrics matched that search.</p>';
  } catch (err) { box.innerHTML = `<p class="note">The lyrics service did not answer (${esc(err.message)}).</p>`; }
});

async function connectApple() {
  try { toast('Opening Apple Music sign-in…'); const ok = await musickit.connect(); toast(ok ? 'Apple Music connected' : 'Sign-in was cancelled');
    if (ok && S.track) { S.resolved = null; S.finding = true; buildStage(); S.resolved = await resolveFull(S.track, S.group?.playables || []); S.finding = false; if (S.resolved.confident && !S.playable) S.playable = S.resolved.best.track.playback; buildStage(); syncBar(); if (S.playable && !player.playing) player.load(S.playable, true); } }
  catch (e) { toast(e.message); }
}
$('#rate').addEventListener('change', e => player.setRate(+e.target.value));
/* ---------------- settings ---------------- */
function openSettings() {
  const s = S.set;
  $('#settingsBody').innerHTML = `
  <div class="field"><label for="sFont">Lyric typeface</label><select id="sFont">${Object.keys(FONTS).map(f => `<option${f === s.font ? ' selected' : ''}>${f}</option>`).join('')}</select></div>
  <div class="field"><label for="sSize">Lyric size · <b id="sSizeV">${Math.round(s.scale * 100)}%</b></label><input type="range" id="sSize" min="60" max="150" value="${s.scale * 100}"></div>
  <div class="field"><label class="inline"><input type="checkbox" id="sCover" ${s.cover ? 'checked' : ''} style="width:auto;height:auto"> Match the album cover</label><p class="note">Colours are read from the artwork when the image host allows it. The four Native Design styles keep their own colours.</p></div>
  <div class="inline"><div class="field"><label>Highlight</label><input type="color" id="sHi" value="${s.hi}"></div><div class="field"><label>Secondary</label><input type="color" id="sSec" value="${s.sec}"></div><div class="field"><label>Text</label><input type="color" id="sText" value="${s.text}"></div><button class="chip" id="sReset">Reset</button></div>
  <div class="field"><label class="inline"><input type="checkbox" id="sHome" ${s.mapHometown !== false ? 'checked' : ''} style="width:auto;height:auto"> Map style: draw the artist’s hometown from OpenStreetMap</label><p class="note">Looks the artist up on MusicBrainz, finds the place on Nominatim, and loads nearby streets from Overpass (shared community services). Only the artist name and a place name are sent. If anything fails, an imagined curving city is drawn instead.</p></div>
  <div class="field"><label class="inline"><input type="checkbox" id="sOpen" ${s.openSearch !== false ? 'checked' : ''} style="width:auto;height:auto"> Find songs through community YouTube search (no key)</label><p class="note">Sends only your search text to volunteer-run Piped/Invidious servers to find a YouTube video id; playback is always YouTube's own player. These servers are unofficial and often down. ${youtube.lastVia ? 'Last used: ' + esc(youtube.lastVia) + '.' : ''}</p></div>
  <div class="field"><label for="sKey">YouTube Data API key (optional)</label><input id="sKey" value="${esc(s.ytKey)}" placeholder="Enables YouTube search" autocomplete="off"><p class="note">Stored only in this browser. Without it you can still paste YouTube links.</p></div>
  <div class="field"><label>Music sources</label>${providers.map(p => `<p class="note"><b>${p.name}</b> · ${p.id === 'itunes' ? 'search only, never played' : p.enabled() ? (p.id === 'musickit' ? (p.authorized ? 'signed in' : 'ready · <button class="lnk" id="amBtn">Sign in</button>') : 'on') : 'off · ' + p.reason()}</p>`).join('')}</div>
  <p class="note">Shortcuts: Space play/pause · ← → seek 5s · [ ] change style · F full screen.</p>`;
  $('#settingsDlg').showModal();
}
$('#settingsBtn').onclick = openSettings;
$('#settingsDlg').addEventListener('input', e => {
  const id = e.target.id, v = e.target.value, s = S.set;
  if (id === 'sFont') s.font = v; if (id === 'sSize') { s.scale = v / 100; $('#sSizeV').textContent = v + '%'; }
  if (id === 'sCover') s.cover = e.target.checked; if (id === 'sOpen') s.openSearch = e.target.checked; if (id === 'sHome') s.mapHometown = e.target.checked; if (id === 'sHi') s.hi = v; if (id === 'sSec') s.sec = v; if (id === 'sText') s.text = v; if (id === 'sKey') s.ytKey = v.trim();
  save(); applyTheme();
});
$('#settingsDlg').addEventListener('click', e => { if (e.target.id === 'amBtn') { $('#settingsDlg').close(); connectApple(); } if (e.target.id === 'sReset') { Object.assign(S.set, { hi: DEF.hi, sec: DEF.sec, text: DEF.text, cover: DEF.cover }); save(); applyTheme(); openSettings(); } });

/* ---------------- boot ---------------- */
applyTheme(); renderRail(); route();

let idleT; const wake = () => { document.body.classList.remove('idle'); clearTimeout(idleT); if (document.body.dataset.view === 'stage') idleT = setTimeout(() => document.body.classList.add('idle'), 3500); };
['pointermove', 'pointerdown', 'keydown', 'touchstart'].forEach(ev => addEventListener(ev, wake, { passive: true })); addEventListener('hashchange', wake); wake();
$('#howBtn').onclick = () => $('#howDlg').showModal();
