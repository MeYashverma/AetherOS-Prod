// Signs an Apple Music developer token (ES256 JWT) with WebCrypto. The private key stays in Worker secrets.
const b64u = b => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const enc = o => b64u(new TextEncoder().encode(JSON.stringify(o)));
const pem = p => Uint8Array.from(atob(p.replace(/-----[A-Z ]+-----/g, '').replace(/\s+/g, '')), c => c.charCodeAt(0));

export async function signAppleToken(env, nowSec = Math.floor(Date.now() / 1000), ttl = 3600) {
  if (!env.APPLE_TEAM_ID || !env.APPLE_KEY_ID || !env.APPLE_PRIVATE_KEY) throw new Error('Apple Music secrets are not configured');
  const key = await crypto.subtle.importKey('pkcs8', pem(env.APPLE_PRIVATE_KEY), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const head = enc({ alg: 'ES256', kid: env.APPLE_KEY_ID }), body = enc({ iss: env.APPLE_TEAM_ID, iat: nowSec, exp: nowSec + ttl });
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, new TextEncoder().encode(`${head}.${body}`));
  return `${head}.${body}.${b64u(sig)}`; // WebCrypto returns raw r||s, which is the JWT ES256 format
}
