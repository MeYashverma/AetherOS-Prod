# Verci 2 Worker (optional but needed for mainstream full-length playback)

Without it the app still works for Audius (and Jamendo with a client id), but most mainstream songs need YouTube search or Apple Music.

1. `npm i -g wrangler` (only to deploy; the web app itself needs no npm) and `wrangler login`.
2. `cd worker && wrangler deploy`, then copy the printed URL into `js/config.js` → `workerUrl`.
3. YouTube: create a key in Google Cloud (enable *YouTube Data API v3*), then `wrangler secret put YT_API_KEY`.
4. Apple Music (needs a paid Apple Developer account): create a MusicKit key (Certificates, IDs & Profiles → Keys). Then
   `wrangler secret put APPLE_TEAM_ID`, `APPLE_KEY_ID`, and `APPLE_PRIVATE_KEY` (paste the whole .p8 text, PKCS8 PEM).
5. Edit `ALLOWED_ORIGIN` in `wrangler.toml` to your site's origin, redeploy.

Nothing secret is ever sent to the browser except the signed one-hour Apple developer token, which Apple designs to be public.
