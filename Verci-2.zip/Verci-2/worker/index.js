// Cloudflare Worker: the only server-side part of Verci 2. Two jobs, both keeping secrets off the client:
//   GET /apple/token         signs a short-lived Apple Music developer token
//   GET /yt/search?q=...     proxies YouTube Data API v3 search (+ durations) with YOUR key, cached for an hour
// Set ALLOWED_ORIGIN to your site (e.g. https://meyashverma.github.io) so other sites cannot spend your quota.
import { signAppleToken } from './apple.js';

const iso = d => { const m = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/.exec(d || ''); return m ? ((+m[1] || 0) * 3600 + (+m[2] || 0) * 60 + (+m[3] || 0)) * 1000 : 0; };
export function normalizeYouTube(search, videos) {
  const dur = {}; (videos.items || []).forEach(v => dur[v.id] = iso(v.contentDetails?.duration));
  return (search.items || []).map(v => ({ videoId: v.id.videoId, title: v.snippet.title, channel: v.snippet.channelTitle, thumbnail: v.snippet.thumbnails?.high?.url || v.snippet.thumbnails?.default?.url || '', durationMs: dur[v.id.videoId] || 0 }));
}

export default {
  async fetch(req, env) {
    const origin = req.headers.get('Origin') || '', allow = env.ALLOWED_ORIGIN || '*';
    const cors = { 'Access-Control-Allow-Origin': allow === '*' || origin === allow ? (allow === '*' ? '*' : origin) : 'null', 'Vary': 'Origin' };
    const json = (o, st = 200, extra = {}) => new Response(JSON.stringify(o), { status: st, headers: { 'Content-Type': 'application/json', ...cors, ...extra } });
    if (req.method === 'OPTIONS') return new Response(null, { headers: { ...cors, 'Access-Control-Allow-Methods': 'GET', 'Access-Control-Max-Age': '86400' } });
    if (allow !== '*' && origin && origin !== allow) return json({ error: 'origin not allowed' }, 403);
    const url = new URL(req.url);
    try {
      if (url.pathname === '/apple/token') return json({ token: await signAppleToken(env) }, 200, { 'Cache-Control': 'private, max-age=1800' });
      if (url.pathname === '/yt/search') {
        const q = (url.searchParams.get('q') || '').slice(0, 120); if (!q) return json({ error: 'missing q' }, 400);
        if (!env.YT_API_KEY) return json({ error: 'YouTube key not configured' }, 501);
        const cache = caches.default, ck = new Request(url.toString()), hit = await cache.match(ck); if (hit) return new Response(hit.body, { headers: { ...Object.fromEntries(hit.headers), ...cors } });
        const s = await (await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&videoCategoryId=10&maxResults=12&q=${encodeURIComponent(q)}&key=${env.YT_API_KEY}`)).json();
        if (s.error) return json({ error: s.error.message }, 502);
        const v = await (await fetch(`https://www.googleapis.com/youtube/v3/videos?part=contentDetails&id=${(s.items || []).map(i => i.id.videoId).join(',')}&key=${env.YT_API_KEY}`)).json();
        const res = json({ items: normalizeYouTube(s, v) }, 200, { 'Cache-Control': 'public, max-age=3600' });
        await cache.put(ck, res.clone()); return res;
      }
      return json({ error: 'not found' }, 404);
    } catch (e) { return json({ error: e.message }, 500); }
  }
};
