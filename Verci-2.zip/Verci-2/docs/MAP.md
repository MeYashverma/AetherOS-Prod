# The Map style

Two worlds feed one renderer (heading-up night navigation, extruded buildings, a route you drive line by line):

## 1. The artist's hometown (real OpenStreetMap data)
`js/geo.js`
1. **MusicBrainz** `GET /ws/2/artist?query=artist:"<name>"` → the artist's `begin-area` (city) and `area` (country). A result is used only if the score is high and the name matches; otherwise there is no hometown.
2. **Nominatim** `GET /search?q=<city, country>` → latitude/longitude.
3. **Overpass** (POST, two public mirrors) → roads, buildings, water, parks, railways and named places (schools, hospitals, car parks, stations, places of worship) within ~1 km. Cached in the browser (Cache Storage); the artist→place lookup is cached for 30 days.
4. `City` projects it to metres, indexes it spatially and builds a **road graph**. Each lyric line drives from the end of the previous line to the next junction (or about 220 m) along real streets, preferring to keep going but sometimes turning.

The map shows the hometown name and "© OpenStreetMap contributors" (required by OSM's licence, ODbL).

## 2. The imagined city (fallback and while loading)
`js/viz/mapworld.js`. **An earlier version of this was a rectangular grid bent by a smooth warp. That was not a real fix and has been removed.** The street network is now irregular by construction:
- Sites are scattered on a jittered lattice that thins out by district (dense downtown, sparse industrial). A Delaunay triangulation gives the Voronoi diagram. **Every Voronoi cell is a city block** (a convex polygon with 3-10 sides) and **its edges are the streets**, so junctions are Y/T shaped with arbitrary angles and blocks vary a lot in size.
- Hierarchy: where smooth wavy fields change sign between two neighbouring blocks, the street between them is an arterial/collector, which yields continuous winding avenues. Some minor streets are dropped (blocks merge, dead ends). Streets are gently curved per edge.
- Smooth highways cross the mesh, with a river (bridges) and a railway. Blocks are filled by their own polygon: houses along the street frontage (rotated with the street), towers, offices, warehouses, parks with ponds, schools, hospitals, malls, car parks.
- The route walks this street graph (3-way junctions, mostly keeping straight, sometimes turning).
Measured on the generated network (`tests/mapgrid.test.mjs`; a grid would score about 100% / 100% / 0% on the first three):
- street directions: 29% axis-aligned (uniformly random would be ~27%);
- junctions: 75% three-way, 0% four-way;
- angles at junctions within 10° of 90°: 16%, spread 144°;
- block side counts 3-10, block-size variation (sd/mean) 0.51.
It is still invented, not real geography. Real streets come from the hometown mode.

## Settings, privacy, limits
- Settings → "Map style: draw the artist's hometown" turns the lookup off (then only the imagined city is used and no request is made).
- Only the artist name and a place name are sent. These are shared community services with fair-use limits (MusicBrainz ~1 request/s, Nominatim ~1 request/s, Overpass is shared), so results are cached and failures fall back silently to the imagined city.
- Not every artist is on MusicBrainz with a hometown; bands and new artists often are not.
- A hometown is where MusicBrainz says the artist began (often a city or district); it may differ from where they live or are famous for.
- **Not verified live**: the sandbox could not reach these services. The pipeline is tested with fixtures: parsing, projection, graph building, route continuity (every step is a real road link), curvature, fallbacks (`tests/geo.test.mjs`, e2e).
