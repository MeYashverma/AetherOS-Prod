# Self-assessment

Written against the brief's seven priorities. Short version: the app is complete in structure and all 13 styles run, but I could not verify the live services from where I built it, so treat "works with real songs" as unconfirmed until the live checklist in TESTING.md passes.

| Priority | Status |
|---|---|
| Real music, not simulated | Real `<audio>` and the official YouTube player. iTunes gives **previews only**, clearly labelled. Full songs come from Audius (indie) or YouTube. Not tested against live hosts. |
| Real lyrics | LRCLIB, matched by title/artist/duration, with manual re-match. Not tested live. |
| Genuine synchronization | Line sync is genuine when LRCLIB has timed lyrics. **Word timing is mostly estimated** (LRCLIB has no word timestamps), and the UI says so. Previews cannot align automatically; the user sets the clip start. |
| 13 distinct styles | All 13 implemented as separate renderers and rendered in tests. They are my interpretations of one-line descriptions: I did not see the macOS app. Expect them to differ from the original in detail. |
| Free, reliable services | Keyless except an optional YouTube key. Reliability of Audius hosts and LRCLIB is outside my control; errors are surfaced, not hidden. |
| Complete, polished, responsive | Desktop and emulated mobile pass layout checks; I reviewed screenshots and fixed overlaps. Not polished by a designer's eye on real devices. |
| No fake features | Nothing decorative is wired to nothing. Known soft spots below. |

## Added in the second round
- **Styles redesigned:** Branches, Web, Codestyle, Native Design (chat, now WhatsApp-style with turns and singer tags) and Notifications (iPhone 17 lock screen). Two new originals: Kinetic and Collage.
- **Not seen:** I could not open the YouTube references (Remainder kinetic typography, the "mix art" video, the shorts): YouTube blocks my sandbox. Kinetic and Collage are built from your descriptions and the screenshots you sent, not from frames. Send frames and I will match them.
- **Multi-singer chat:** works only when the lyric file carries singer tags; LRCLIB rarely does. Otherwise turns are a heuristic, not the real singers.
- **Auto full version:** conservative on purpose. Without a YouTube key only Audius is searched, so most mainstream songs keep the preview.
- **UI:** the style rail, volume, timing and source controls moved behind a style picker and a ⋯ menu; controls fade after 3.5 s on the lyric view.

## Round 3
- **Previews removed.** Only full-length sources play; if none agrees the UI says so. Consequence: without the Worker (YouTube/Apple Music), mainstream songs usually have no playable source. That is the honest state, not a bug.
- **Provider architecture** implemented (see docs/ARCHITECTURE.md). Apple MusicKit, Jamendo and Worker-backed YouTube are written but **unverified** (no credentials/network). SoundCloud deliberately not implemented.
- **Styles:** Branches, Web, Code, Map rebuilt; Kinetic rewritten; Y2K and Cinema added. The three YouTube references (M.I.A., Magdalena Bay, typography edits) could not be opened, so these are interpretations. Map's city is invented.
- Brief item 1 asked me to inspect "my existing project": the working directory was this repo (built in earlier rounds), so the assessment is of that.

## Round 4
- **Keyless full songs for mainstream music** now go: iTunes identity → Piped/Invidious search (video id only) → ranked → official YouTube embed, with automatic fallback to the next agreeing candidate. This is the only free route to mainstream full songs that I found; it is **best-effort and unverified live**, because the community instances are unreliable and my sandbox cannot reach them. Reliability upgrade: your own Worker + free YouTube key.
- No stream extraction, no YouTube Music private API, no accounts.

## Round 5
- **Embedding blocks:** cannot be removed legitimately. Mitigated by probing candidates with YouTube's official oEmbed endpoint, widening candidates, and automatic failover (docs/YOUTUBE_OPTIONS.md). Songs whose every upload blocks embedding will still show "No full version found". The Android clients' stream-extraction technique was not added (access-control circumvention).
- **Wrong Jamendo/Audius songs:** search hits that do not resemble the query are now dropped; they are also only auto-played when title, artist, length and version agree.
- **Restyled:** Map (road classes, highways, river with bridges, rail, POIs, named streets), Branches (cherry tree over a pond), Web (macro dew web), Chrome (replaces Y2K).
- **Responsive:** 10 screen sizes tested for layout in headless Chromium. Not tested on real devices.
- Performance: Branches initially froze the page (thousands of gradients per frame); fixed with pre-rendered petal sprites. Real-device frame rates are unmeasured.

## Round 6: Map
- **Curving roads (corrected):** my first attempt only warped a rectangular grid, which is still a grid; that was wrong. The imagined city is now an irregular Voronoi street network, verified by measurements (docs/MAP.md, tests/mapgrid.test.mjs). The real-data mode follows whatever the real streets do.
- **Artist hometown:** MusicBrainz → Nominatim → Overpass → drawn and driven map (docs/MAP.md). **Unverified against the live services** (fixtures only). Real data can be sparse or heavy for some places; the 1 km query is capped and falls back to the imagined city on error.
- Hometown ≠ residence; some artists have no hometown on MusicBrainz.

## Known gaps
- Live APIs unverified; Chromium only; no Safari/iOS audio testing.
- YouTube search and playback paths untested.
- Audius matches for mainstream songs are often absent, so mainstream full-length playback depends on YouTube.
- Map is a procedural grid; Money's "$1 per word" is a design device, not data.
- Accessibility: focus rings, labels and reduced-motion are in place; screen-reader behaviour of the animated styles was not tested.
- Fisheye/Ship stack all words of the song, so very long songs are fine but unusual lyric formats (very long lines, non-Latin scripts) were not tested.
- No licence file added; choose one.
