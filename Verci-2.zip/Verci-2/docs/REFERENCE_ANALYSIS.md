# Reference project analysis (Convx, BitChord)

Both repositories were cloned and read (structure, headers, comments), not copied. **Both are GPL-3.0**, so no code was ported; Verci 2 implements the same *ideas* independently.

## What they do
- **Convx** (Kotlin Multiplatform): a `PlaybackQueueController` and an `AudioStreamResolver` interface (`resolve(track) → PlaybackAudioStream`) separate "what to play" from "how to get audio". A `ModuleTrackMatcher` only substitutes a catalogue track when **title, artist identity and duration agree** (duration within ±10 s). Lyrics, smart transitions and equalizer are separate feature modules.
- **BitChord** (Kotlin/Android): an InnerTube client for YouTube Music catalogue and search, a `StreamResolver` that turns a videoId into a streamable URL, a `SourceRegistry`/`ModuleSource` for pluggable providers, and a large `TrackMatcher` (about 1,000 lines).

## Concepts adopted (reimplemented in JavaScript)
| Idea | Where in Verci 2 |
|---|---|
| Provider adapters behind one interface, a registry | `js/providers/*`, `registry.js` |
| One normalised track model | `js/track.js` |
| Resolve "wanted recording" → best playable source, separate from search | `registry.resolveFull`, `rank.js` |
| Version markers (live, remix, acoustic, sped up, ...) must agree **in both directions** | `track.versionsOf`, `rank.scoreCandidate` |
| Two-stage queries: title+artist, then title only | `services.lrclibFind`, `registry.resolveFull` |
| Duration is a check/ranking signal, not identity | `rank.js`, `registry.groupTracks` |
| Never substitute silently; only auto-pick when confident | `rankFull().confident` |
| Central playback manager with queue, state, capabilities | `js/playback.js` |

## Techniques NOT used, and why
- **InnerTube `player` requests, client catalogues, PoTokens, cipher tiers, NewPipe extraction, URL probing.** This is how those apps obtain raw audio from YouTube. It is unauthorised stream extraction that works around YouTube's access controls (what your brief rules out), it needs Android/JVM runtimes and bot-protection handling that a browser does not have, and the endpoints are browser-CORS-blocked. Verci 2 plays YouTube **only** through the official IFrame Player.
- **InnerTube catalogue/search from the browser.** Not an official interface, no CORS, no stable contract. Search uses the official YouTube Data API v3 through your Worker instead.
- **Google account sign-in for YouTube Music.** Requires handling Google session cookies; not implemented.
- **Android-specific pieces**: ExoPlayer, background media sessions, Room databases, native audio analysis (automix/beat tracking), offline downloads. Not applicable to a static site.

## Provider assessment
| Provider | Catalogue/search | Full playback in a browser | Needs | Status here |
|---|---|---|---|---|
| iTunes Search | yes, with artwork/duration/explicit | **No** (30 s previews only; never played) | nothing | metadata only |
| Apple MusicKit JS | yes | Yes, for signed-in subscribers | Apple Developer account (paid), Worker to sign the token | implemented, **unverified** (no credentials here) |
| YouTube | official Data API v3 (quota) | Yes, **embedded IFrame player only**, not an audio file | API key in the Worker | implemented, **unverified live** |
| Audius | yes | Yes (stream URL permitted by Audius) | nothing | implemented, fixture-tested only |
| Jamendo | yes | Yes (CC-licensed full tracks) | free client id | implemented, **unverified** |
| SoundCloud | API closed to new apps | would need the Widget embed | an approved app | **not implemented** (no honest path) |
