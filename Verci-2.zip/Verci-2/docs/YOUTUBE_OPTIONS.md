# Getting free, full-length songs: what exists, what I used

Researched 23 Nov 2026 (web search of project docs, issue trackers and Piped/Invidious documentation). The sandbox could not open YouTube or any instance, so nothing below was tested against live hosts.

| Option | Free | Full songs | Works from a static site | Verdict |
|---|---|---|---|---|
| YouTube IFrame Player | yes | yes (when the owner allows embedding) | yes | **Used for all playback of YouTube videos** |
| YouTube Data API v3 search | free quota (~100 searches/day) | n/a (search only) | needs a key; keep it in the Worker | Supported (Worker or your own key) |
| **Piped public instances** (`/search?filter=music_songs`) | yes, no key | n/a (search only) | yes, if the instance sends CORS | **Used, search only**, best-effort (see below) |
| Invidious public instances (`/api/v1/search`) | yes | n/a | some instances | Fallback only; the public network has shrunk to a handful of hosts and YouTube keeps blocking it |
| Their stream/proxy URLs (`/streams`, `videoplayback`) | yes | yes | no | **Not used.** It is unauthorised extraction, instances get IP-blocked for it, and it breaks the YouTube embed rules |
| YouTube Music InnerTube (what BitChord/Convx use) | yes | yes | no (CORS, PoToken, client spoofing) | **Not used** (access-control circumvention) |
| Audius | yes | yes (independent artists) | yes | Used |
| Jamendo | yes (free client id) | yes (CC music) | yes | Used if configured |
| Internet Archive | yes | yes (old/public-domain/live-taper) | yes | Not added; almost never matches mainstream songs |
| Apple Music / Spotify | no (subscription) | yes | MusicKit | Apple Music supported if you have a subscription; Spotify excluded |
| SoundCloud | API closed to new apps | via widget only | no search | Not implemented |

## How the keyless route works
1. Search text goes to up to 3 Piped instances at a time (15 are listed in Piped's public-instances documentation), asking for `filter=music_songs`, which returns YouTube-Music-style songs with a clean title, artist and duration. If every Piped host is down, Invidious hosts that advertise `api` and `cors` are tried.
2. Results are ranked against the iTunes identity (title, artist, length, version markers, "Topic" channel). Only a confident match is auto-selected.
3. The video id is played in the **official embedded player**. If it will not embed, the app tries the next candidate that still agrees, then reports the failure.

## Honest limits
- Community instances are volunteer-run and unofficial. YouTube blocks them (Invidious's public list fell to 3 hosts by March 2026; Piped has ~15 and some CDN-backed hosts, but also reports regular blocking). Expect this tier to fail at times. Failed hosts are put on a 10-minute cool-down.
- YouTube has sent a cease-and-desist to Invidious. Using these services is the operators' risk and a grey area; the app only sends them search text and never touches their streams. It can be switched off in Settings.
- Privacy: your search text goes to a third-party server (shown in Settings). For a reliable, accountable setup, use the Worker with your own free YouTube key instead.
- Embedding can be disabled by the video's owner; official "Topic"/audio uploads usually allow it, music videos often do not.

## "The owner of this video does not allow embedded playback"
This is YouTube's rule for the official player, not a bug. What the app now does about it, inside the rules:
1. **Probes before choosing.** Each YouTube candidate is checked with YouTube's official oEmbed endpoint (keyless; it answers 401 for videos whose owner disabled embedding). Blocked uploads are pushed down so an embeddable one (often the "Topic"/official-audio upload, or a lyric video) wins. If the probe cannot run (network/CORS) the candidate is not penalised.
2. **More candidates.** Community search adds plain-video results (query + "audio") to the YouTube-Music song results, so there is more than one upload to choose from.
3. **Automatic failover.** If a chosen video still refuses to embed, the next candidate that still agrees on title, artist and length is tried; if none is left the banner says so (and says when every match is embedding-blocked).
4. **Better sources first.** Apple Music (subscriber), Audius and Jamendo are ranked on the same scale, and Jamendo/Audius hits that do not resemble the search text are dropped so wrong songs do not appear.

**What I did not do:** the Android clients (InnerTune, Metrolist, SimpMusic, Echo's YouTube Music extension, BitChord, Convx) get around this by asking YouTube's private InnerTube `player` endpoint for the raw audio stream while presenting themselves as an Android/iOS client, with proof-of-origin tokens and signature deciphering. That bypasses the embedding restriction and YouTube's access controls, so it is excluded here (as in your brief), and it also cannot be called from a web page (no CORS, bot checks). If you want that approach for yourself, it belongs in a native app or a server you operate and are responsible for, not in this site.

Many "VEVO"/music-video uploads block embedding while the same song's Topic/audio upload does not, so for songs that stay blocked the usual fix is a better candidate, which is exactly what the probe and failover search for.
