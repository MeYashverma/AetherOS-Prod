# Verci research

**Source:** https://www.verci.xyz/ fetched 19 Nov 2026 (text of the page; the page's images and video were not viewable, and the macOS app itself was not downloaded or run, because it is a macOS 15+ menu-bar app and this work was done on Linux). Everything below is from the site's own copy. Style implementations in this repo are my interpretation of those one-line descriptions, not copies of the app's rendering.

## Latest version
Verci 2.0.1 (DMG on the site). A menu-bar app for macOS 15+ that follows Spotify or Apple Music and lights lyrics word by word on the lock screen. $9.99 (Black Friday), then $12.99. Verci 2 added a window: live previews of each style on a short built-in track, Select/pin buttons, Size / Font / Lock Screen / Aesthetics panels, per-player status checklists (Spotify/Apple Music open, permission, track, lyrics found and how they are timed), and a ±1 s lyric-timing nudge that resets each song. Seven typefaces (SF Pro, SF Rounded, New York, Helvetica Neue, Avenir Next, Futura, Didot). Aesthetics: lyric, highlight and secondary colours, or match the album cover; the four Native Design styles keep their own colours. The site says about 9 in 10 tested tracks have word-level lyrics.

## The 13 styles, as the site lists them
| Group | Style | Site description |
|---|---|---|
| Kinetic type | Ship | Words land one by one on a wall that drifts in 3D |
| | Fisheye | Tight stack of three words bulging through a lens |
| | Visual | Centred stack, an icon for every word that has one |
| | Fisheye Visual | Fisheye with icons beside words that have one |
| Motion scenes | Codestyle | Lyric typed out as code under a blinking red cursor |
| | Codestyle Visual | Codestyle with icons |
| | Branches | A line draws itself, each word lights a node |
| | Web | Each line spun into a spider's web, a strand per word |
| | Constellation | Each line traced as a constellation, star by star |
| Native Design | Native Design | Song as a message thread, a bubble per line |
| | Native Design Money | A run of payments, one per line |
| | Native Design Map | A walk across San Francisco, a pin per line |
| | Native Design Notifications | Lines arrive as lock-screen notifications, stacks and widgets |

## Differences from the brief's list (latest release wins)
| Brief says | Latest Verci calls it | Implemented as |
|---|---|---|
| Messages | **Native Design** | Native Design (messages) |
| Ship — web-like strands | **Web** | Web |
| Flashbang Visual — 3D drifting words | **Ship** (3D drifting wall) | Ship |
| Native Design Notifications / Map / Money | same | same |
| remaining six | same | same |

There is no "Flashbang Visual" on the current site; the brief's description of it matches today's Ship, and the brief's "Ship" description matches today's Web. The count is still 13.

## Not reproducible
- Verci's word-level timings (from the player's own lyric data). LRCLIB is line-timed, so this app estimates words and says so.
- The Map's San Francisco geography, the app's SF fonts, and its built-in preview track.

## Originals added (not in Verci)
- **Kinetic** — poster-style lines, words slam in from different directions.
- **Collage** — mixed-media words (serif italic, heavy grotesk, typewriter, outline, highlighter, label, circled, script).
Both were inspired by reference videos I could not open; they are interpretations.
