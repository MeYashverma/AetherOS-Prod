# Testing

## What was run
1. Unit tests (node): `lrc` (12), `match` (5), `rank` (5, now incl. version agreement), `typing` (5), `registry` (5, dedupe/grouping), `mapgrid` (6: measured street directions, junction types and angles, block shapes, route), `geo` (7: hometown parsing, projection, OSM→graph, route follows real roads, curving roads in both worlds), `embed` (3: embeddable-first resolution), `openyt` (6: Piped/Invidious normalisation, instance rotation, cool-down, fallback), `worker` (3, **real ES256 signing verified against the public key**, YouTube normalisation). All pass.
2. `python3 tests/e2e.py` — headless Chromium driving the real app against fixtures: unified search and dedupe, automatic full-version choice, honest "No full version found" state, **no preview request ever made**, real `<audio>` playback, source sheet, all 17 styles with screenshots, chat with singer tags and on-screen typing keyboard, iPhone lock screen, settings, mobile. **56/56 pass** and `python3 tests/responsive.py` **40/40** (10 screen sizes × 4 styles: no sideways scroll, player inside the screen, style bar clear of it, usable lyric area) (incl. keyless community search resolving a YouTube source, no stream-URL requests, and a visible player-failure state). Output: `tests/e2e-results.json`, screenshots in `docs/screenshots/`.

## Provider status (be precise)
| Provider | Real API call made by me | Playback verified |
|---|---|---|
| Audius, iTunes, LRCLIB, YouTube, Jamendo, MusicKit, MusicBrainz, Nominatim, Overpass | **No** (sandbox cannot reach them) | **No** |
| Worker Apple JWT signing | n/a | Verified with real ES256 crypto in Node |
Nothing here may be called "verified end-to-end" until you run the live checklist.

## What that does NOT prove
- **No live service was contacted.** The build sandbox blocks itunes.apple.com, lrclib.net, audius.co and youtube.com, so the e2e test replaces those responses with fixtures (request interception) and plays a generated tone, with invented test lyrics. It proves the app's plumbing, not that today's live APIs return what the code expects.
- Only Chromium was tested. Not Safari, Firefox, or real phones (mobile is emulated).
- The YouTube player and YouTube Data API paths were not exercised at all.
- Album-colour extraction depends on the image host's CORS headers; the fallback path was exercised, the real hosts were not.

## Live checklist (please run; ~10 minutes)
1. Search "daft punk" → results with real artwork; tabs show iTunes / Audius.
2. Click an iTunes result → preview plays, badge says "30s preview", banner explains clip start. Drag "clip starts at" until lyrics match.
3. Source sheet → pick an Audius or YouTube full version → badge changes to full track; lyrics follow.
4. Find a song with lyrics on LRCLIB → lines highlight in time; try all 13 styles with `[` `]`.
5. Song with no LRCLIB entry → "No lyrics found" and manual search works.
6. Paste a YouTube link → plays in the visible mini-player; with a key in Settings, the YouTube tab searches.
7. Open on a phone: controls reachable, no sideways scroll, audio plays after tapping.
Report any failures as issues; endpoint changes are isolated in `js/services.js`.
