# Architecture

```
index.html, css/, js/app.js            UI (unchanged look and features)
js/config.js                           PUBLIC settings only (workerUrl, jamendoClientId)
js/track.js                            Track model + recording-version detection
js/providers/
  itunes.js     identity/metadata only (plays: false)
  musickit.js   Apple Music catalogue + MusicKit playback (needs Worker token + subscriber)
  audius.js     full streams, keyless
  jamendo.js    full CC streams, free client id
  youtube.js    search via Worker/key; playback via IFrame only
  registry.js   providers[], searchAll(), groupTracks() (dedupe), resolveFull() (rank + confidence)
js/rank.js, js/match.js                Candidate ranking, title/artist cleaning
js/playback.js PlaybackManager         queue, state, capabilities; engines: audio | youtube | musickit
worker/        Cloudflare Worker       /apple/token (ES256 JWT), /yt/search (key stays server-side)
```

**Flow.** Search → every enabled provider in parallel → tracks normalised → duplicates of the same recording merged (title + primary artist + version markers + duration ±8 s) → one row per recording. Clicking a row → lyrics are looked up from the catalogue identity while `resolveFull` ranks playable candidates from all playing providers. A source is chosen automatically only if title, artist, duration and version all agree; otherwise the UI says "No full version found" and lists ranked options. Previews are never an option.

**Engines.** `audio` (HTML audio; Audius/Jamendo), `youtube` (IFrame Player; shown in a visible mini-player; not routed through the audio element), `musickit` (MusicKit JS; subscribers only). `playback.caps` reports what each supports (seek, volume, rate).

**Secrets.** None in the repo. The Worker holds `YT_API_KEY` and the Apple private key; the browser only receives a signed one-hour Apple developer token.
