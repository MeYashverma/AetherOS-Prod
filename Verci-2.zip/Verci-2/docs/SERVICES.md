# Services and limitations

All calls are made from the browser. No keys are embedded. "Verified" below means verified from this repo's sandbox, which could **not** reach any of these hosts (see TESTING.md). Endpoints and behaviours are from each service's public documentation and my knowledge of them; confirm them with the live checklist.

| Service | Used for | Endpoint | Key | Limits and honest caveats |
|---|---|---|---|---|
| iTunes Search API | Song identity, artwork, durations (preview URL ignored) | `itunes.apple.com/search` | none | Metadata only; its 30 s previews are never played. Documented rate limit is roughly 20 requests/minute per IP; results are cached for 10 min. |
| Apple Marketing RSS | "Popular right now" | `rss.applemarketingtools.com/api/v2/us/music/most-played/24/songs.json` | none | US chart only. Shelf hides itself if unavailable. Chart items are resolved to iTunes tracks on click. |
| Audius | Full-length streams | `api.audius.co` (host list) then `/v1/tracks/search` and `/v1/tracks/{id}/stream` | none (`app_name` only) | Independent artists, not the mainstream catalogue. Lyrics coverage on LRCLIB is spotty for these tracks. Host is picked at random from Audius's list. |
| YouTube IFrame Player | Full-length playback of mainstream songs | `youtube.com/iframe_api` | none | Official embed, shown in a visible mini-player (not hidden). Some videos block embedding (error shown). |
| YouTube Data API v3 | Optional search | `googleapis.com/youtube/v3/search` | **optional**, user's own free key | ~100 searches/day on the free quota. Key stays in this browser's localStorage. Without it, paste a link (oEmbed supplies title/author). |
| LRCLIB | Lyrics | `lrclib.net/api/get`, `/api/search` | none | Line-level LRC and plain text only; no word timestamps except rare enhanced-LRC files. Match by title/artist/duration; the "Source and lyrics" sheet lets you pick another match. |
| Google Fonts | Lyric typefaces | `fonts.googleapis.com` | none | Falls back to system fonts if blocked. |

## Considered and not used
- **Spotify Web API / SDK:** playback needs the user's Premium account plus OAuth, and Spotify stopped returning preview URLs to new apps in late 2024. Fails the "no paid subscription for core use" rule.
- **Jamendo:** legitimate and free, but needs a registered client ID. Left out to keep the app keyless; could be added the same way as Audius.
- **NetEase:** word-level lyrics exist but its API is undocumented, not CORS-enabled for browsers, and terms of use are unclear.
- **Invidious/Piped/other YouTube proxies, any ripping:** unofficial and against the brief's legality rules.

## Behaviour that follows from the limits
- iTunes results play a preview only; the sheet offers Audius matches and YouTube as full-length alternatives.
- Preview clips need a manual "clip starts at" setting before lyrics align.
- Estimated words are flagged in the player bar and the Codestyle status line.

## Added in round 3
| Service | Used for | Key | Notes |
|---|---|---|---|
| Apple MusicKit JS | Catalogue + full playback for subscribers | Developer token signed by your Worker | Not verifiable without credentials: unverified. |
| Jamendo API | Full CC tracks | free client id | Off until `jamendoClientId` is set. |
| Cloudflare Worker | Signs Apple token; proxies YouTube search | secrets live in Worker | Free tier is enough. |

## Round 4: keyless YouTube search
Piped public instances (and Invidious as fallback) for **search only**; see docs/YOUTUBE_OPTIONS.md. Never their stream URLs. Unverified live; best-effort; can be disabled in Settings.
