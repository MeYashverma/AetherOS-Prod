"""End-to-end test of Verci 2 in headless Chromium.

IMPORTANT: the sandbox this was written in has no access to itunes.apple.com, lrclib.net, audius.co,
or youtube.com, so network responses are replaced with fixtures (route interception). This proves the
app's plumbing (search -> select -> play -> parse -> sync -> 13 styles -> controls -> error states)
but NOT that the live services are up. See docs/TESTING.md for the live-service checklist.
"""
import json, re, sys, threading, http.server, socketserver, functools, pathlib
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
FIX = ROOT / 'tests/fixtures'
SHOTS = ROOT / 'docs/screenshots'
LRC = (FIX / 'synced.lrc').read_text()
H = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(ROOT))
H.log_message = lambda *a: None
srv = socketserver.TCPServer(('127.0.0.1', 0), H); PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = f'http://127.0.0.1:{PORT}/'

def itunes(term):
    return {'resultCount': 3, 'results': [
        {'wrapperType': 'track', 'kind': 'song', 'trackId': 1, 'trackName': 'Paper Kite', 'artistName': 'Test Artist', 'collectionName': 'Fixtures', 'artworkUrl100': 'https://is1.mzstatic.test/a/100x100bb.jpg', 'previewUrl': 'https://audio.test/preview.wav', 'trackTimeMillis': 45000},
        {'wrapperType': 'track', 'kind': 'song', 'trackId': 2, 'trackName': 'Second Song', 'artistName': 'Test Artist', 'collectionName': 'Fixtures', 'artworkUrl100': 'https://is1.mzstatic.test/b/100x100bb.jpg', 'previewUrl': 'https://audio.test/preview.wav', 'trackTimeMillis': 45000},
        {'wrapperType': 'track', 'kind': 'song', 'trackId': 3, 'trackName': 'Open Song', 'artistName': 'Test Artist', 'collectionName': 'Fixtures', 'artworkUrl100': 'https://is1.mzstatic.test/c/100x100bb.jpg', 'previewUrl': 'https://audio.test/preview.wav', 'trackTimeMillis': 45000}]}

state = {'lyrics': 'synced', 'calls': []}

def handle(route):
    req = route.request; url = req.url; state['calls'].append(url)
    def js(obj, status=200): route.fulfill(status=status, content_type='application/json', headers={'access-control-allow-origin': '*'}, body=json.dumps(obj))
    if url.startswith(BASE): return route.continue_()
    if 'fonts.g' in url or 'youtube.com/iframe_api' in url: return route.abort()
    if 'musicbrainz.org/ws/2/artist' in url: return js({'artists': [{'id': 'x', 'name': 'Test Artist', 'score': 100, 'area': {'name': 'Testland', 'iso-3166-1-codes': ['TL']}, 'begin-area': {'name': 'Testville'}}]})
    if 'nominatim.openstreetmap.org/search' in url: return js([{'lat': '35.0', 'lon': '-100.0', 'display_name': 'Testville'}])
    if 'overpass' in url and 'interpreter' in url:
        if state.get('osm') == 'fail': return route.fulfill(status=503, headers={'access-control-allow-origin': '*'}, body='busy')
        return js(json.loads((FIX / 'osm.json').read_text()))
    if 'itunes.apple.com/search' in url: return js(itunes(url))
    if re.search(r'pipedapi|piped-api|api\.piped', url) and '/search' in url:
        if 'second' in url.lower(): return js({'items': []})
        return js({'items': [{'url': '/watch?v=abcdefghijk', 'title': 'Open Song', 'uploaderName': 'Test Artist - Topic', 'duration': 45, 'thumbnail': 'https://img.audius.test/a.png'}]})
    if 'rss.applemarketingtools.com' in url: return js({'feed': {'results': [{'id': '9', 'name': 'Paper Kite', 'artistName': 'Test Artist', 'artworkUrl100': 'https://is1.mzstatic.test/a/100x100bb.jpg'}]}})
    if url.rstrip('/') == 'https://api.audius.co': return js({'data': ['https://audius.test']})
    if 'audius.test/v1/tracks/search' in url: return js({'data': [{'id': 'x0', 'title': 'Paper Kite', 'user': {'name': 'Test Artist'}, 'duration': 45, 'artwork': {'480x480': 'https://img.audius.test/a.png'}, 'is_streamable': True}, {'id': 'x1', 'title': 'Indie Tone', 'user': {'name': 'Some Artist'}, 'duration': 45, 'artwork': {'480x480': 'https://img.audius.test/a.png'}, 'is_streamable': True}]})
    if '.mzstatic.test' in url or 'img.audius.test' in url: return route.fulfill(status=200, content_type='image/png', headers={'access-control-allow-origin': '*'}, body=(FIX / 'art.png').read_bytes())
    if 'audio.test' in url or 'audius.test/v1/tracks/x' in url and '/stream' in url:
        data = (FIX / 'tone.wav').read_bytes(); rng = req.headers.get('range'); h = {'accept-ranges': 'bytes', 'content-type': 'audio/wav', 'access-control-allow-origin': '*'}
        if rng:
            m = re.match(r'bytes=(\d+)-(\d*)', rng); a = int(m.group(1)); b = int(m.group(2)) if m.group(2) else len(data) - 1
            h.update({'content-range': f'bytes {a}-{b}/{len(data)}', 'content-length': str(b - a + 1)}); return route.fulfill(status=206, headers=h, body=data[a:b + 1])
        h['content-length'] = str(len(data)); return route.fulfill(status=200, headers=h, body=data)
    if 'lrclib.net/api/get' in url or 'lrclib.net/api/search' in url:
        meta = {'id': 1, 'trackName': 'Second Song' if 'second' in url.lower() else 'Paper Kite', 'artistName': 'Test Artist', 'duration': 45}
        if state['lyrics'] == 'none': return js([] if 'search' in url else {'statusCode': 404}, 200 if 'search' in url else 404)
        if state['lyrics'] == 'plain': r = {**meta, 'syncedLyrics': None, 'plainLyrics': 'First plain line\nSecond plain line'}
        elif state['lyrics'] == 'duet': r = {**meta, 'syncedLyrics': '\n'.join(f'[00:{2+i*3:02d}.00]{n}: line number {i} here' for i, n in enumerate(['Ann','Bob','Bob','Ann','Bob','Ann','Ann','Bob'])), 'plainLyrics': 'x'}
        else: r = {**meta, 'syncedLyrics': LRC, 'plainLyrics': 'x'}
        return js([r] if 'search' in url else r)
    return route.abort()

results = []
def check(name, ok, detail=''):
    results.append({'test': name, 'pass': bool(ok), 'detail': str(detail)}); print(('PASS ' if ok else 'FAIL ') + name, detail)

def pick(page, sid):
    page.click('#styleBtn'); page.click(f'#styleDlg [data-style={sid}]')

def more(page):
    if page.locator('#more').is_hidden(): page.click('#moreBtn')

def seek(page, sec):
    page.evaluate("""s => { const r = document.querySelector('#seek'), d = document.querySelector('#tDur').textContent.split(':'); const dur = (+d[0])*60 + (+d[1]); r.value = s/dur*1000; r.dispatchEvent(new Event('input')); r.dispatchEvent(new Event('change')); }""", sec)

with sync_playwright() as p:
    b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    ctx = b.new_context(viewport={'width': 1280, 'height': 800}); ctx.route('**/*', handle)
    page = ctx.new_page(); errors = []
    page.on('pageerror', lambda e: errors.append(str(e))); page.on('console', lambda m: m.type == 'error' and 'Failed to load resource' not in m.text and errors.append(m.text))
    page.goto(BASE); page.wait_for_selector('#trending .card')
    check('home shows popular shelf from the RSS feed', page.locator('#trending .card').count() == 1)
    page.screenshot(path=str(SHOTS / 'home.png'))

    page.fill('#q', 'paper kite'); page.press('#q', 'Enter'); page.wait_for_selector('#resultBody .row')
    check('unified search merges providers: one row per recording', page.locator('#resultBody .row').count() == 3, [t for t in page.locator('#resultBody .row b').all_inner_texts()])
    check('only recordings with a full-length source are tagged Full', page.locator('#resultBody .tag.ok').count() == 1, page.locator('#resultBody .tag.ok').count())
    page.screenshot(path=str(SHOTS / 'results.png'))
    page.locator('#resultBody .row').first.click()
    page.wait_for_selector('#vizRoot .viz', timeout=8000)
    check('selecting a song opens the lyric stage with a style running', page.locator('#vizRoot .viz').count() == 1)
    check('full version is chosen automatically when title, artist and length agree', 'Audius' in page.inner_text('#npBadge') and 'preview' not in page.inner_text('#npBadge').lower(), page.inner_text('#npBadge'))
    check('player bar shows title and artist', 'Paper Kite' in page.inner_text('#npTitle') and 'Test Artist' in page.inner_text('#npArtist'))
    check('no preview banner when a full version plays', page.locator('#banner').is_hidden() or 'preview' not in page.inner_text('#banner').lower())

    page.wait_for_timeout(1500)
    t1 = page.inner_text('#tCur'); page.wait_for_timeout(1500); t2 = page.inner_text('#tCur')
    check('real audio is playing and progress advances', t1 != t2, f'{t1} -> {t2}')
    page.click('#playBtn'); page.wait_for_timeout(300); a = page.inner_text('#tCur'); page.wait_for_timeout(900)
    check('pause stops progress', a == page.inner_text('#tCur'))
    page.click('#playBtn'); seek(page, 20); page.wait_for_timeout(400)
    check('seeking moves playback', page.inner_text('#tCur') in ('0:20', '0:21', '0:22'), page.inner_text('#tCur'))
    more(page); page.evaluate("() => { const v = document.querySelector('#vol'); v.value = 20; v.dispatchEvent(new Event('input')); }")
    check('volume control persists', json.loads(page.evaluate("localStorage.getItem('verci2')"))['vol'] == 0.2)

    more(page); page.click('#sourcesBtn'); page.wait_for_selector('[data-full]')
    check('source sheet ranks candidates and marks the best match', 'Best match' in page.inner_text('#fullList'), page.inner_text('#fullList')[:80])
    check('lyric search box starts with a cleaned query', page.input_value('#lyrQ').strip() != '' and 'Official' not in page.input_value('#lyrQ'))
    page.keyboard.press('Escape')
    check('mixed word/line timing is described honestly', 'partly word-synced' in page.get_attribute('#npBadge', 'title'), page.get_attribute('#npBadge', 'title'))

    names = page.eval_on_selector_all('#styleGrid [data-style]', 'els => els.map(e => e.dataset.style)')
    check('style picker lists all 17 styles (13 Verci + 4 originals)', len(names) == 17, names)
    times = {'visual': 10, 'default': 12.8}
    for sid in names:
        pick(page, sid); seek(page, 12.6); page.wait_for_timeout(1100)
        page.click('#playBtn') if page.locator('.player.playing').count() == 0 else None
        page.wait_for_timeout(900)
        info = page.evaluate("""() => { const v = document.querySelector('#vizRoot .viz'); const cv = v.querySelector('canvas'); let ink = 0;
          if (cv && cv.width && cv.height) { const g = cv.getContext('2d'); const d = g.getImageData(0,0,cv.width,cv.height).data; for (let i = 3; i < d.length; i += 16) if (d[i] > 20) ink++; }
          return {text: v.innerText.trim().slice(0, 80), kids: v.querySelectorAll('*').length, ink, w: v.clientWidth, h: v.clientHeight}; }""")
        ok = info['w'] > 100 and info['h'] > 100 and (info['ink'] > 200 if sid in ('branches', 'web', 'constellation', 'native-map') and info['text'] == '' else (len(info['text']) > 0 or info['ink'] > 200))
        check(f'style {sid} renders live lyric content', ok, json.dumps(info)[:140])
        page.screenshot(path=str(SHOTS / f'style-{sid}.png'))
    # word-level (enhanced LRC) segment
    pick(page, 'codestyle'); seek(page, 28.0); page.wait_for_timeout(1200)
    check('genuine word timestamps drive word reveal', page.evaluate("() => document.querySelectorAll('.code .live .w[data-s=\"2\"]').length") >= 3)
    pick(page, 'visual'); page.keyboard.press(']'); page.wait_for_timeout(300)
    check('keyboard shortcut ] switches style', page.get_attribute('#styleGrid [data-style=fisheye-visual]', 'aria-pressed') == 'true')
    more(page); page.click('#nudgeLate'); check('timing nudge adjusts', page.inner_text('#nudgeVal') == '+0.5s')

    # next track / queue
    page.click('#nextBtn'); page.wait_for_timeout(800)
    check('next track moves through results', 'Second Song' in page.inner_text('#npTitle'))
    page.wait_for_timeout(1500)
    check('no agreeing full version: honest unavailable state, never a preview', 'No full version' in page.inner_text('#banner') and 'No audio' in page.inner_text('#npBadge') and page.locator('.player.playing').count() == 0, page.inner_text('#npBadge') + ' | ' + page.inner_text('#banner'))
    page.click('#settingsBtn'); page.wait_for_selector('#sFont'); page.select_option('#sFont', index=2); page.fill('#sSize', '120') if False else None
    check('settings lists providers and says iTunes is never played', 'never played' in page.inner_text('#settingsBody'))
    check('settings dialog opens and saves a font', 'Fraunces' in json.loads(page.evaluate("localStorage.getItem('verci2')"))['font'])
    page.keyboard.press('Escape')

    # map: the artist's hometown from (fixture) OpenStreetMap data, then fallbacks
    pick(page, 'native-map'); seek(page, 12.6); page.wait_for_timeout(2500)
    info = page.evaluate("() => ({place: document.querySelector('.nd-map .ptxt').textContent, attr: document.querySelector('.nd-map .attr').textContent})")
    check('map draws the artist hometown from OpenStreetMap data with attribution', info['place'] == 'Testville, Testland' and 'OpenStreetMap' in info['attr'], json.dumps(info))
    page.screenshot(path=str(SHOTS / 'style-native-map-hometown.png'))
    check('map reported where it asked: MusicBrainz, Nominatim, Overpass', all(any(k in u for u in state['calls']) for k in ('musicbrainz.org', 'nominatim.openstreetmap.org', 'overpass')))

    # keyless community search finds a YouTube video id; playback is the official player only
    page.evaluate("sessionStorage.clear()"); page.evaluate("location.hash='/search/open'"); page.wait_for_selector('#resultBody .row')
    rows = page.locator('#resultBody .row b').all_inner_texts(); idx = [i for i, r in enumerate(rows) if 'Open Song' in r][0]
    page.locator('#resultBody .row').nth(idx).click(); page.wait_for_timeout(2000)
    check('no key, no Worker: community search resolves a YouTube source for a mainstream-style song', 'YouTube' in page.inner_text('#npBadge'), page.inner_text('#npBadge') + ' | ' + page.inner_text('#banner'))
    check('a YouTube player failure is reported, not hidden', 'player' in page.inner_text('#banner').lower() or 'could not' in page.inner_text('#banner').lower(), page.inner_text('#banner'))
    check('stream URLs of community instances are never requested', not any('/streams/' in u or 'videoplayback' in u or 'latest_version' in u for u in state['calls']))

    # multi-singer chat + iPhone lock screen
    state['lyrics'] = 'duet'; page.evaluate("sessionStorage.clear()"); page.evaluate("location.hash='/search/duet'"); page.wait_for_selector('#resultBody .row'); page.locator('#resultBody .row').first.click(); page.wait_for_timeout(1500)
    pick(page, 'native-messages'); seek(page, 11.5); page.wait_for_timeout(1500)
    info = page.evaluate("() => ({names: [...document.querySelectorAll('.nd-wa .b s')].map(e => e.textContent), out: document.querySelectorAll('.nd-wa .b.out').length, inn: document.querySelectorAll('.nd-wa .b.in').length, head: document.querySelector('.nd-wa header b').textContent})")
    check('chat uses real singer tags (singer name shown, header names the first singer)', len(info['names']) >= 1 and info['names'][0] in ('Ann', 'Bob') and info['head'] == 'Ann', json.dumps(info))
    seek(page, 4.0); page.wait_for_timeout(700)
    kb = page.evaluate("() => ({open: document.querySelector('.nd-wa .kbw').classList.contains('open'), typed: document.querySelector('.nd-wa .inp').innerText.trim(), keys: document.querySelectorAll('.nd-wa .kb i').length})")
    check('green lines are typed on an on-screen keyboard before sending', kb['open'] and 0 < len(kb['typed']) < len('line number 1 here') and kb['keys'] >= 30, json.dumps(kb))
    page.screenshot(path=str(SHOTS / 'style-chat-keyboard.png'))
    seek(page, 11.5); page.wait_for_timeout(900)
    page.screenshot(path=str(SHOTS / 'style-chat-duet.png'))
    state['lyrics'] = 'synced'; page.evaluate("sessionStorage.clear()"); page.evaluate("location.hash='/search/plain'"); page.wait_for_selector('#resultBody .row'); page.locator('#resultBody .row').first.click(); page.wait_for_timeout(1500)
    pick(page, 'native-notifications'); seek(page, 14); page.wait_for_timeout(1200)
    check('iPhone lock screen shows clock, island and a notification', page.locator('.nd-ios .island').count() == 1 and page.locator('.nd-ios .n').count() >= 1 and ':' in page.inner_text('.nd-ios .clock'))
    pick(page, 'native-messages'); seek(page, 14); page.wait_for_timeout(1500)
    check('chat without singer tags still builds turns', page.locator('.nd-wa .b.in').count() + page.locator('.nd-wa .b.out').count() >= 2)
    page.screenshot(path=str(SHOTS / 'style-chat-turns.png'))

    # error states
    state['lyrics'] = 'none'; page.evaluate("sessionStorage.clear()"); page.evaluate("location.hash='/search/zzz'"); page.wait_for_selector('#resultBody .row'); page.locator('#resultBody .row').first.click(); page.wait_for_timeout(1500)
    check('missing lyrics shows an honest empty state', 'No lyrics found' in page.inner_text('#vizRoot'))
    page.screenshot(path=str(SHOTS / 'state-no-lyrics.png'))
    state['lyrics'] = 'plain'; page.evaluate("sessionStorage.clear()"); page.evaluate("location.hash='/search/yyy'"); page.wait_for_selector('#resultBody .row'); page.locator('#resultBody .row').first.click(); page.wait_for_timeout(1500)
    check('untimed lyrics are shown as untimed text, not fake-synced', 'timed' in page.inner_text('#banner') and page.locator('#vizRoot .plain').count() == 1)
    page.screenshot(path=str(SHOTS / 'state-plain.png'))
    check('no 30-second preview was ever requested', not any('audio.test/preview' in u for u in state['calls']))
    check('no uncaught page errors', not errors, errors[:3])

    # map fallbacks in clean contexts: Overpass down, and the setting switched off
    state['lyrics'] = 'synced'
    for mode in ('fail', 'off'):
        state['osm'] = 'fail' if mode == 'fail' else 'ok'; state['calls'].clear()
        c2 = b.new_context(viewport={'width': 1280, 'height': 800}); c2.route('**/*', handle)
        if mode == 'off': c2.add_init_script("localStorage.setItem('verci2', JSON.stringify({mapHometown:false, style:'native-map'}))")
        else: c2.add_init_script("localStorage.setItem('verci2', JSON.stringify({style:'native-map'}))")
        p2 = c2.new_page(); p2.goto(BASE); p2.fill('#q', 'kite'); p2.press('#q', 'Enter'); p2.wait_for_selector('#resultBody .row'); p2.locator('#resultBody .row').first.click(); p2.wait_for_timeout(3500)
        txt = p2.evaluate("() => document.querySelector('.nd-map .ptxt')?.textContent")
        check(f'map falls back to the imagined curving city ({mode})', txt == 'Imagined city', txt)
        if mode == 'off': check('with the setting off no hometown request is made', not any(k in u for u in state['calls'] for k in ('musicbrainz', 'nominatim', 'overpass')))
        else: p2.screenshot(path=str(SHOTS / 'style-native-map-imagined.png'))
        c2.close()
    state['osm'] = 'ok'

    # mobile
    state['lyrics'] = 'synced'
    m = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, is_mobile=True, has_touch=True); m.route('**/*', handle)
    mp = m.new_page(); mp.goto(BASE); mp.screenshot(path=str(SHOTS / 'mobile-home.png'))
    mp.fill('#q', 'kite'); mp.press('#q', 'Enter'); mp.wait_for_selector('#resultBody .row'); mp.locator('#resultBody .row').first.click(); mp.wait_for_selector('#vizRoot .viz')
    mp.click('[data-tab=x]') if False else None
    mp.wait_for_timeout(800)
    for sid in ('visual', 'native-messages', 'constellation'):
        mp.click('#styleBtn'); mp.click(f'#styleDlg [data-style={sid}]'); mp.wait_for_timeout(700); mp.screenshot(path=str(SHOTS / f'mobile-{sid}.png'))
    sw = mp.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
    check('mobile layout has no horizontal overflow', sw)
    b.close()

passed = sum(r['pass'] for r in results)
print(f'\n{passed}/{len(results)} checks passed')
(ROOT / 'tests/e2e-results.json').write_text(json.dumps(results, indent=1))
sys.exit(0 if passed == len(results) else 1)
