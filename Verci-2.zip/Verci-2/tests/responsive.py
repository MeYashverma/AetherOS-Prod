"""Layout checks across screen sizes (phones, tablets, laptops, ultra-wide), using the same network fixtures as e2e.py."""
import json, pathlib, sys
__file__ = str(pathlib.Path(__file__).resolve())
exec(open(__file__.replace('responsive.py', 'e2e.py')).read().split("results = []")[0])
from playwright.sync_api import sync_playwright
VIEWS = [('phone-se', 360, 640, 2, True), ('phone', 390, 844, 3, True), ('phone-max', 430, 932, 3, True), ('phone-landscape', 844, 390, 3, True), ('phone-se-landscape', 667, 375, 2, True),
         ('tablet', 768, 1024, 2, True), ('tablet-landscape', 1024, 768, 2, True), ('laptop', 1366, 768, 1, False), ('desktop', 1920, 1080, 1, False), ('ultrawide', 2560, 1080, 1, False)]
STYLES = ['visual', 'native-messages', 'native-map', 'branches']
res = []
def check(n, ok, d=''): res.append(ok); print(('PASS ' if ok else 'FAIL ') + n, d)
SH = ROOT / 'docs/screenshots/responsive'; SH.mkdir(parents=True, exist_ok=True)
with sync_playwright() as p:
    b = p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    for name, w, h, dpr, mob in VIEWS:
        ctx = b.new_context(viewport={'width': w, 'height': h}, device_scale_factor=dpr, is_mobile=mob, has_touch=mob); ctx.route('**/*', handle); page = ctx.new_page()
        page.goto(BASE); page.screenshot(path=str(SH / f'{name}-home.png'))
        page.fill('#q', 'paper kite'); page.press('#q', 'Enter'); page.wait_for_selector('#resultBody .row'); page.locator('#resultBody .row').first.click(); page.wait_for_selector('#vizRoot .viz'); page.wait_for_timeout(1200)
        for sid in STYLES:
            page.click('#styleBtn'); page.click(f'#styleDlg [data-style={sid}]'); page.wait_for_timeout(900)
            m = page.evaluate("""() => { const r = s => { const e = document.querySelector(s); if (!e || e.hidden) return null; const b = e.getBoundingClientRect(); return [b.left, b.top, b.right, b.bottom]; };
              return { sw: document.documentElement.scrollWidth, iw: innerWidth, ih: innerHeight, player: r('#player'), bar: r('#stagebar'), viz: r('#vizRoot'), top: r('.top'), search: r('#searchForm') }; }""")
            inside = m['player'] and m['player'][0] >= -1 and m['player'][2] <= m['iw'] + 1 and m['player'][3] <= m['ih'] + 1
            sep = not m['bar'] or m['bar'][3] <= m['player'][1] + 2
            check(f'{name} {sid}: no sideways scroll, player inside screen, style bar clear of player, lyric area usable',
                  m['sw'] <= m['iw'] + 1 and inside and sep and (m['viz'][3] - m['viz'][1]) >= min(180, m['ih'] * 0.4), json.dumps({k: m[k] for k in ('sw', 'iw', 'ih')}) + ' viz_h=' + str(round(m['viz'][3] - m['viz'][1])))
            if sid in ('native-map', 'branches', 'native-messages'): page.screenshot(path=str(SH / f'{name}-{sid}.png'))
        ctx.close()
    b.close()
print(f'\n{sum(res)}/{len(res)} responsive checks passed'); sys.exit(0 if all(res) else 1)
