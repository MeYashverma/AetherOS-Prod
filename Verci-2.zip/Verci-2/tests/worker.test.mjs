import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
import { signAppleToken } from '../worker/apple.js';
import { normalizeYouTube } from '../worker/index.js';
let n = 0; const t = async (m, f) => { await f(); n++; console.log('ok -', m); };
const kp = await webcrypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
const pkcs8 = Buffer.from(await webcrypto.subtle.exportKey('pkcs8', kp.privateKey)).toString('base64');
const env = { APPLE_TEAM_ID: 'TEAM123456', APPLE_KEY_ID: 'KEY1234567', APPLE_PRIVATE_KEY: `-----BEGIN PRIVATE KEY-----\n${pkcs8.match(/.{1,64}/g).join('\n')}\n-----END PRIVATE KEY-----` };
const u = s => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
await t('Apple developer token is a valid ES256 JWT that verifies against the public key', async () => {
  const tok = await signAppleToken(env, 1700000000, 3600), [h, b, s] = tok.split('.');
  assert.deepEqual(JSON.parse(u(h)), { alg: 'ES256', kid: 'KEY1234567' });
  assert.deepEqual(JSON.parse(u(b)), { iss: 'TEAM123456', iat: 1700000000, exp: 1700003600 });
  assert.equal(u(s).length, 64);
  assert.ok(await webcrypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, kp.publicKey, u(s), new TextEncoder().encode(`${h}.${b}`)));
});
await t('missing secrets fail loudly instead of signing garbage', async () => { await assert.rejects(() => signAppleToken({})); });
await t('YouTube results are normalised with durations', () => {
  const r = normalizeYouTube({ items: [{ id: { videoId: 'abc' }, snippet: { title: 'A - B', channelTitle: 'A - Topic', thumbnails: { high: { url: 'u' } } } }] }, { items: [{ id: 'abc', contentDetails: { duration: 'PT3M20S' } }] });
  assert.deepEqual(r, [{ videoId: 'abc', title: 'A - B', channel: 'A - Topic', thumbnail: 'u', durationMs: 200000 }]);
});
console.log(n + ' tests passed');
