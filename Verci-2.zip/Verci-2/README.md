# Verci 2 for the web

Search a song, play it, and watch its real lyrics arrive in 15 styles: the 13 of [Verci](https://www.verci.xyz/) (the macOS lock-screen lyrics app) plus two originals. Static site, no build step, no account, no paid API.

**Run it:** `python3 -m http.server 8000` then open http://localhost:8000 (ES modules need http, not file://).
**Deploy it:** push to `main`; `.github/workflows/pages.yml` publishes to GitHub Pages (Settings → Pages → Source: GitHub Actions).

## What plays and where lyrics come from

**Only full-length songs are played. 30-second previews are never played.** iTunes is used only to identify songs (title, artist, length, artwork).

| Need | Service | Setup |
|---|---|---|
| Song identity, artwork | iTunes Search API | none |
| Full songs, mainstream | **Apple Music** (MusicKit JS, signed-in subscribers) | Worker + Apple Developer key |
| Full songs, mainstream | **YouTube** (official IFrame player). Search: community Piped/Invidious instances (no key, best-effort), or the Worker/your own free API key (reliable) | none for the keyless route |
| Full songs, independent | Audius | none |
| Full songs, Creative Commons | Jamendo | free client id in `js/config.js` |
| Lyrics | LRCLIB | none |

Out of the box, mainstream songs are found through community YouTube search instances (free, unofficial, sometimes down) and played in YouTube's own player; independent music plays from Audius. For reliability add the Worker ([worker/README.md](worker/README.md)). What I checked and what I rejected: [docs/YOUTUBE_OPTIONS.md](docs/YOUTUBE_OPTIONS.md). Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md). Reference analysis: [docs/REFERENCE_ANALYSIS.md](docs/REFERENCE_ANALYSIS.md). Research on Verci: [docs/RESEARCH.md](docs/RESEARCH.md). Tests: [docs/TESTING.md](docs/TESTING.md). Self-assessment: [docs/ASSESSMENT.md](docs/ASSESSMENT.md).

## The 17 styles (layouts checked from 360 px phones to 2560 px ultra-wide, portrait and landscape)

Kinetic type: Ship, Fisheye, Visual, Fisheye Visual. Motion scenes: Codestyle (editor, shell and git diff, cutting between each other with a glitch), Codestyle Visual, Branches (a cherry tree over a moonlit pond, with reflection, paper tags and drifting petals), Web (a macro dew-covered orb web; each word is caught in a glass droplet and a spider drops to it), Constellation. Native Design: Native Design (a WhatsApp-style chat whose green lines are typed on an on-screen keyboard), Money, Map (night turn-by-turn navigation: it looks up where the artist is from and draws that place from real OpenStreetMap streets, with the route following real roads; otherwise an imagined city whose streets are an irregular Voronoi network (Y-junctions, winding avenues, blocks of many shapes), with a river and bridges, a railway, schools, hospitals, car parks and parks; see docs/MAP.md), Notifications (iPhone 17 lock screen). Originals: Kinetic (full-bleed word-per-cut), Collage, Chrome (liquid chrome type over a neon grid), Cinema. In the Map, the imagined city is invented; time left, arrival time and stops left are real playback numbers.

## Full version and lyrics matching

Each song is resolved against every enabled playing provider and ranked on title, artist, length and version (a remix is never swapped in for the original and vice versa). The best source is used automatically only when they all agree; otherwise you see "No full version found" and a ranked list under ⋯ → Source and lyrics. Lyrics are searched by song name first and by artist only where it helps; the uploader or channel is never used.

## Honesty rules the app follows

- Previews are never played. If no full-length source agrees, the app says so.
- LRCLIB gives line timestamps. Word timing inside a line is **estimated** and the player bar says so. Words are only treated as genuine when the lyric file carries word tags.
- Untimed lyrics are shown as plain text, not pretend-synced. Missing lyrics show an empty state with manual search.
- The Map style is a procedurally drawn street grid, not real geography. Money counts $1 per word sung.

## Layout

`index.html` · `css/` · `js/lrc.js` (parser, tested) · `js/services.js` · `js/player.js` · `js/app.js` · `js/match.js` + `js/rank.js` (matching, tested) · `js/viz/` (one class per style) · `tests/` · `docs/`

Shortcuts: Space play/pause · ← → seek 5 s · [ ] style · F full screen.
Verci is © its author; this project is an independent web interpretation and is not affiliated with it.
